
@extends('admin.layouts.adminlayout')
@section('content')
<!-- .page-content -->
@include('admin.PattaEntryManagement.nav')
@include('admin.PattaEntryManagement.Patta.form')
@endsection
