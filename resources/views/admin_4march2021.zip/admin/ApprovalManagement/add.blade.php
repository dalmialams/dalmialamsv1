
@extends('admin.layouts.adminlayout')
@section('content')
<!-- .page-content -->
@include('admin.ApprovalManagement.form')
@endsection
