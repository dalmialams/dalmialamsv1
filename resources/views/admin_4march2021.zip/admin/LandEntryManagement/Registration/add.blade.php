
@extends('admin.layouts.adminlayout')
@section('content')
<!-- .page-content -->
@include('admin.LandEntryManagement.nav')
@include('admin.LandEntryManagement.Registration.form')
@endsection
