   <!-- Start .row -->
                <div class="col-lg-12 col-md-12 sortable-layout">
                    <!-- col-lg-6 start here -->

                    <!-- End .panel -->
                    <div class="panel panel-default plain toggle panelMove panelClose panelRefresh">
                        <!-- Start .panel -->
                        <div class="panel-heading">
                            <h4 class="panel-title"><i class="im-target"></i> Geolocation 123</h4>
                        </div>
                        <div class="panel-body">
                            <div id="map" style="width:100%;height:600px;"></div>
                        </div>
                    </div>
                    <!-- End .panel -->
                </div>         
    <!-- End .row -->




