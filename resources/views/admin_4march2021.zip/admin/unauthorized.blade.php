
@extends('admin.layouts.adminlayout')
@section('content')
<!-- .page-content -->
<h2>Unauthorized Access</h2>
@endsection
