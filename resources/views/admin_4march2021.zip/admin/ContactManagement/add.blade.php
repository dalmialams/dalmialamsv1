
@extends('admin.layouts.adminlayout')
@section('content')
<!-- .page-content -->
@include('admin.ContactManagement.form')
@endsection
