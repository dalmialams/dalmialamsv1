
@extends('admin.layouts.adminlayout')
@section('content')
<style>
    .welcome_bg{
        background:url('assets/img/login_bg.jpg') no-repeat center bottom;
        background-size:cover;
    }
</style>
<div class="container">
   
</div>
@endsection
