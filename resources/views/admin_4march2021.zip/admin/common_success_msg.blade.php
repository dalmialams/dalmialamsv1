
@extends('admin.layouts.adminlayout')
@section('content')
<!-- .page-content -->
<h2></h2>
<div>{!! Session::get('message')!!}</div>
@endsection
