<style>
.down-color{ color:#6969d4; }
a:hover, a:focus {
    color: #000 !important;
    text-decoration: underline;
}
</style>



<div class="panel panel-primary  toggle panelMove panelClose panelRefresh">
    <!-- Start .panel -->
    <div class="panel-heading">
        <h4 class="panel-title">Shape Data List</h4>
    </div>
    <div class="panel-body">
        <table id="village_table" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th  class="text-center">No</th> 
                    <th  class="text-center">Type </th>
                    <th  class="text-center">Action </th>

                </tr>
            </thead>
            <tbody>
                <?php
                if ($shape_data) {
					//t($villageList);die;
                    foreach ($shape_data as $key => $value) {
                        ?>
                        <tr>
                            <td  class="text-center"><?= ++$key ?></td>
                            <td  class="text-center"><?php
                                echo $shp_type;
                                ?>
                            </td>
                            
                            <td class="text-center">
							<a onclick="return confirm('Do you want to remove ?');" title="Remove" href="<?= url('document-management/document/manage-shape-remove/'.$value->ogc_fid) ?>"><i class="ace-icon fa fa-remove bigger-130"></i></a>
							</td>

                        </tr>
                        <?php
                    }
                }
                ?>

            </tbody>
        </table>
	
    </div>
</div>

