
@extends('admin.layouts.adminlayout')
@section('content')
<!-- .page-content -->
@include('admin.ShapeFileManagement.form')
@endsection
