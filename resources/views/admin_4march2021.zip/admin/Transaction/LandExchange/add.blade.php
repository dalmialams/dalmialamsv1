@extends('admin.layouts.adminlayout')
@section('content')
<!-- .page-content -->
@include('admin.Transaction.LandExchange.form')
@endsection
