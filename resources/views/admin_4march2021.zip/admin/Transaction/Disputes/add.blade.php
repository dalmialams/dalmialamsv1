@extends('admin.layouts.adminlayout')
@section('content')
<!-- .page-content -->
@include('admin.Transaction.Disputes.form')
@endsection
