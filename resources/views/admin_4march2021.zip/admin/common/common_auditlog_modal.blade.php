<style>

.modal a.close-modal {
    top: -2.5px !important;
    right: 0.5px !important;
}
</style>
<div id="enumeration_dataModal" class="modal" style="max-width: 8950px; margin-top:4%">
  <p>Log Details</p>
 
</div>