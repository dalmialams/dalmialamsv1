
<!-- .page-sidebar -->
<aside id="sidebar" class="page-sidebar hidden-md hidden-sm hidden-xs">
    <!-- Start .sidebar-inner -->
    <div class="sidebar-inner">
        <!-- Start .sidebar-scrollarea -->
        <div class="sidebar-scrollarea">
            <!--  .sidebar-panel -->
            <!--                        <div class="sidebar-panel">
                                        <h5 class="sidebar-panel-title">Profile</h5>
                                    </div>-->
            <!-- / .sidebar-panel -->
            <!--                        <div class="user-info clearfix">
                                        <img src="img/avatars/128.jpg" alt="avatar">
                                        <span class="name">SuggeElson</span>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-default btn-xs"><i class="l-basic-gear"></i>
                                            </button>
                                            <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">settings <span class="caret"></span>
                                            </button>
                                            <ul class="dropdown-menu right" role="menu">
                                                <li><a href="profile.html"><i class="fa fa-edit"></i>Edit profile</a>
                                                </li>
                                                <li><a href="#"><i class="fa fa-money"></i>Windraws</a>
                                                </li>
                                                <li><a href="#"><i class="fa fa-credit-card"></i>Deposits</a>
                                                </li>
                                                <li class="divider"></li>
                                                <li><a href="login.html"><i class="fa fa-power-off"></i>Logout</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>-->
            <!--  .sidebar-panel -->
            <div class="sidebar-panel">
                <!--<h5 class="sidebar-panel-title">Navigation</h5>-->
            </div>
            <!-- / .sidebar-panel -->
            <!-- .side-nav -->
            <div class="side-nav">
               
                 {!! $MyNavBar->asUl(array('class' => 'nav'),array('class' => 'sub')) !!}
            </div>
           
            <!-- / side-nav -->
            <!--  .sidebar-panel -->
           
        </div>
        <!-- End .sidebar-scrollarea -->
    </div>
    <!-- End .sidebar-inner -->
</aside>
<!-- / page-sidebar -->
