
@extends('admin.layouts.adminlayout')
@section('content')
<!-- .page-content -->
@include('admin.AuditManagement.form')
@endsection
